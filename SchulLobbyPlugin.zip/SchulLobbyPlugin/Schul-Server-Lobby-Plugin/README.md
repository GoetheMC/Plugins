# Schul-Server-Lobby-Plugin
 Lobby Plugin für den Schulserver
